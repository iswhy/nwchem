      subroutine fexit
      end
